import React, { useState } from "react";
import "./styles.css";

export default function App() {
  const [searchInput, setSearchInput] = useState("");

  return (
    <div className="App">
      <h1>Search whatever you need!</h1>
      <input
        type="text"
        placeholder="Search.."
        value={searchInput}
        onChange={(e) => setSearchInput(e.target.value)}
      />
    </div>
  );
}
