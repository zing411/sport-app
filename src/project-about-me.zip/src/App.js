import "./styles.css";

export default function App() {
  const sportsImages = [
    "https://i.pinimg.com/236x/c0/67/80/c067801c211b8eb3145fa5463bde0282--sports-stars-roger-federer.jpg"
  ];

  const myStyle = {
    width: 300,
    borderColor: "blue"
  };

  return (
    <div className="App">
      <div
        style={{
          borderStyle: "solid",
          borderColor: "blue"
        }}
      >
        <h1>Welcome to About Me Page!</h1>
      </div>
      <div>
        {sportsImages.map((image) => (
          <div key={image}>
            <img style={myStyle} src={image} alt="Sport Image" />
          </div>
        ))}
      </div>
      <p>Description</p>
    </div>
  );
}
